import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import express from 'express';
import fs from 'fs';
import path from 'path';
const bodyParser = require('body-parser')

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.post('/api/updateFile', (req, res) => {
  const { content } = req.body;

  if (!content) {
    return res.status(400).json({ success: false, message: '缺少内容' });
  }

  const filePath = path.join(__dirname, 'xx.txt');

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err && err.code !== 'ENOENT') {
      return res.status(500).json({ success: false, message: '读取文件失败' });
    }

    const newData = (data ? data + '\n' : '') + content;

    fs.writeFile(filePath, newData, 'utf8', err => {
      if (err) {
        return res.status(500).json({ success: false, message: '写入文件失败' });
      }

      res.json({ success: true });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});